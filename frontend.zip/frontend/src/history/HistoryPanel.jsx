import "react"

export default function HistoryPanel() {
    return <></>
}