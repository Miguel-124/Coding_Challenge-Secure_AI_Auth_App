import {ClerkProviderWithRoutes} from './auth/ClerkProviderWithRoutes.jsx'
import {Route, Routes} from 'react-router-dom'
import {Layout} from './layout/Layout.jsx'
import {Challenge} from './challenge/ChallengeGenerator.jsx'
import {AuthenticationPage} from './auth/AuthenticatorPage.jsx'
import {HistoryPanel} from './history/HistoryPanel.jsx'
import './App.css'

function App() {
  return <ClerkProviderWithRoutes>
      <Routes>
        <Route path="/sign-in/*" element={<AuthenticationPage />}/>
        <Route path="/sign-up/*" element={<AuthenticationPage />}/>
        <Route element={<Layout />}/>
            <Route path="/" element={<ChallengeGenerator />} />
            <Route path="/history " element={<HistoryPanel />} />
      </Routes>
  </ClerkProviderWithRoutes>
}

export default App
