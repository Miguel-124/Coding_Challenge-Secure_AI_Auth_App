import "react"

export default function Layout() {
    return <></>
}