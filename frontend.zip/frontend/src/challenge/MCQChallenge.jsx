import "react"

export default function MCQChallenge() {
    return <></>
}