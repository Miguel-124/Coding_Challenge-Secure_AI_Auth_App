import "react"

export default function ChallengeGenerator() {
    return <></>
}
